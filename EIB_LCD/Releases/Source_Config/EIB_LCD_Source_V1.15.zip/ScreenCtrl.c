/** \file ScreenCtrl.c
 *  \brief Functions controlling fixed system pages
 *	This module is part of the EIB-LCD Controller Firmware
 *
 *	Implemented functions:
 *	- display and control system information page
 *	- display and control project download page
 *	- display and control EIB busmonitor page
 *	- display and control hardware monitor function
 *	- display and control screen lock function
 *
 *	Copyright (c) 2011-2013 Arno Stock <arno.stock@yahoo.de>
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License version 2 as
 *	published by the Free Software Foundation.
 *
 */
#include "System.h"

volatile uint32_t filesize;
// 0 = none
// 1 = system setup man page
// 2 = system download page
// 3 = system download progress page
// 4 = system setup page
uint8_t	system_page_active;
uint8_t sd_files;
_LCD_FILE_NAMES_t *sd_file_names;
// timer for screen locking
volatile uint16_t screen_lock;
uint16_t	monitor_y;
uint16_t	monitor_color;

#define	BUTTON_WIDTH	100
#define	BUTTON_WIDTH_SMALL	45
#define	BUTTON_HEIGHT	30

#define	SETUP_BUTTON_XPOS		004
#define	SETUP_BUTTON_YPOS		204
#define	MONITOR_BUTTON_XPOS		4
#define	MONITOR_BUTTON_YPOS		204
#define	BUSMON_BUTTON_XPOS		4
#define	BUSMON_BUTTON_YPOS		204
#define PAUSE_BUTTON_XPOS		40
#define PAUSE_BUTTON_YPOS		204
#define RESUME_BUTTON_XPOS		40
#define RESUME_BUTTON_YPOS		204
#define HARDWARE_MONITOR_BUTTON_XPOS	109
#define HARDWARE_MONITOR_BUTTON_YPOS	204
#define	DOWNLOAD_BUTTON_XPOS	109
#define	DOWNLOAD_BUTTON_YPOS	204
#define	EXIT_BUTTON_XPOS		214
#define	EXIT_BUTTON_YPOS		204
#define	DOWNLOAD_LIST_UP_XPOS	004
#define DOWNLOAD_LIST_UP_YPOS	204
#define	DOWNLOAD_LIST_DOWN_XPOS	054
#define DOWNLOAD_LIST_DOWN_YPOS	204

#define CHARACTER_WIDTH			8
#define BUTTON_TEXT_OFFSET		8

// draws a simple button
void draw_button (uint16_t x_pos, uint16_t y_pos, uint8_t width, char *face) {

	// draw inner area
	tft_fill_rect (BYTE2COLOR (128,128,128), x_pos+1,y_pos+1,x_pos+width-1,y_pos+BUTTON_HEIGHT-1);

	// draw outer lines
	tft_fill_rect (BYTE2COLOR (0,0,0), x_pos,				y_pos,	x_pos+width,	y_pos+1);
	tft_fill_rect (BYTE2COLOR (0,0,0), x_pos,				y_pos,	x_pos+1,			y_pos+BUTTON_HEIGHT);
	tft_fill_rect (BYTE2COLOR (0,0,0), x_pos+width-1,y_pos,	x_pos+width,	y_pos+BUTTON_HEIGHT);
	tft_fill_rect (BYTE2COLOR (0,0,0), x_pos,	y_pos+BUTTON_HEIGHT-1,	x_pos+width,	y_pos+BUTTON_HEIGHT);

	// get length of text
	uint16_t len = strlen (face) * CHARACTER_WIDTH;
	// put text
	showzifustr(x_pos+(width - len)/2, y_pos+BUTTON_TEXT_OFFSET, (unsigned char*) face, BYTE2COLOR (0,0,255),BYTE2COLOR (128,128,128));
}

// 1 = hit, 0=not hit
uint8_t check_button (uint16_t x_pos, uint16_t y_pos, uint8_t width, t_touch_event *evt) {

	return 	(x_pos < evt->lx) && (y_pos < evt->ly) && (x_pos + width > evt->lx) && (y_pos + BUTTON_HEIGHT > evt->ly);

}

char* (*list_get_item_string) (uint8_t);
uint8_t	list_length;
uint8_t list_selected_item;
uint16_t list_x_pos;
uint16_t list_y_pos;
uint16_t list_w;
uint16_t list_h;
uint8_t	 list_lines_in_box;
#define	LIST_BACKGROUND_COLOR	BYTE2COLOR (20,20,20)
#define	LIST_SELECT_BOX_COLOR	BYTE2COLOR (150,150,150)
#define	LIST_SELECTED_BOX_COLOR	BYTE2COLOR (255,0,0)
#define	LIST_TEXT_CHAR_COLOR	BYTE2COLOR (255,255,255)
#define	LIST_TEXT_BACK_COLOR	BYTE2COLOR (150,150,150)
#define	LIST_TEXT_XOFS			8
#define LIST_LINE_HEIGHT		13
#define	LIST_Y_LINE_MARGIN		1
#define	LIST_SELECTION_BOX_X	1
#define	LIST_SELECTION_BOX_Y	4
#define	LIST_SELECTION_BOX_W	5
#define	LIST_SELECTION_BOX_H	5

void init_selection_list (char* (*get_list_item)(uint8_t), uint8_t length, uint8_t selected, uint16_t x, uint16_t y, uint16_t w, uint16_t h) {

	// set variables
	list_get_item_string = get_list_item;
	list_length = length;
	list_selected_item = selected;
	list_x_pos = x;
	list_y_pos = y;
	list_w = w;
	list_h = h;

	// clear paint area
	tft_fill_rect (LIST_BACKGROUND_COLOR, list_x_pos, list_y_pos, list_x_pos + list_w -1, list_y_pos + list_h -1);
	// draw contents
	int i;
	uint16_t line_y;
	line_y = list_y_pos + LIST_Y_LINE_MARGIN;
	for (i = 0; (i < list_length) && ((list_y_pos + list_h) > (line_y + LIST_LINE_HEIGHT + LIST_Y_LINE_MARGIN)); i++) {
		// draw selection box
		tft_fill_rect (LIST_SELECT_BOX_COLOR, list_x_pos + LIST_SELECTION_BOX_X, 							line_y + LIST_SELECTION_BOX_Y, 
											  list_x_pos + LIST_SELECTION_BOX_X + LIST_SELECTION_BOX_W-1, 	line_y + LIST_SELECTION_BOX_Y + LIST_SELECTION_BOX_H -1);
		// show selected
		if (i == list_selected_item)
			tft_fill_rect (LIST_SELECTED_BOX_COLOR,	list_x_pos + LIST_SELECTION_BOX_X+1,						line_y + LIST_SELECTION_BOX_Y+1, 
											  		list_x_pos + LIST_SELECTION_BOX_X + LIST_SELECTION_BOX_W -2, 	line_y + LIST_SELECTION_BOX_Y + LIST_SELECTION_BOX_H -2);
		// put text string
		showzifustr(list_x_pos+LIST_TEXT_XOFS,line_y, (unsigned char*) list_get_item_string (i), LIST_TEXT_CHAR_COLOR, LIST_TEXT_BACK_COLOR);

		// goto next line
		line_y += LIST_LINE_HEIGHT;
	}
}

void selection_list_update_selection(int step) {

uint16_t line_y;
int	new_list_selected_item;

	// calculate current line
	line_y = list_y_pos + LIST_Y_LINE_MARGIN + list_selected_item * LIST_LINE_HEIGHT;
	// clear selection
	tft_fill_rect (LIST_SELECT_BOX_COLOR, list_x_pos + LIST_SELECTION_BOX_X, 							line_y + LIST_SELECTION_BOX_Y, 
										  list_x_pos + LIST_SELECTION_BOX_X + LIST_SELECTION_BOX_W-1, 	line_y + LIST_SELECTION_BOX_Y + LIST_SELECTION_BOX_H -1);
	// update selection
	new_list_selected_item = list_selected_item + step;
	if (new_list_selected_item >= list_length)
		new_list_selected_item = 0;
	if (new_list_selected_item < 0)
		new_list_selected_item = list_length -1;
	list_selected_item = new_list_selected_item;

	// calculate current line
	line_y = list_y_pos + LIST_Y_LINE_MARGIN + list_selected_item * LIST_LINE_HEIGHT;
	// mark selection
	tft_fill_rect (LIST_SELECTED_BOX_COLOR,	list_x_pos + LIST_SELECTION_BOX_X+1,						line_y + LIST_SELECTION_BOX_Y+1, 
									  		list_x_pos + LIST_SELECTION_BOX_X + LIST_SELECTION_BOX_W-2, 	line_y + LIST_SELECTION_BOX_Y + LIST_SELECTION_BOX_H-2);
}

uint8_t selection_list_get_selected_item (void) {
	return list_selected_item;
}


#define	DOWNLOAD_PROGRESS_XPOS	10
#define	DOWNLOAD_PROGRESS_YPOS	120
#define	DOWNLOAD_PROGRESS_WIDTH	 300
#define	DOWNLOAD_PROGRESS_HEIGHT 20
#define	DOWNLOAD_BAR_XPOS	15
#define	DOWNLOAD_BAR_YPOS	129
#define	DOWNLOAD_BAR_WIDTH	290
#define	DOWNLOAD_BAR_HEIGHT 2

void show_download_progress (uint32_t downloadsize) {

uint32_t	progress;

	progress = (downloadsize * DOWNLOAD_BAR_WIDTH) / filesize;
	tft_fill_rect (BYTE2COLOR (255,255,0), DOWNLOAD_BAR_XPOS, DOWNLOAD_BAR_YPOS,
				 		DOWNLOAD_BAR_XPOS+progress,
						DOWNLOAD_BAR_YPOS+DOWNLOAD_BAR_HEIGHT);

}

void remove_download_progress() {

	tft_fill_rect (BYTE2COLOR (255,255,255), DOWNLOAD_PROGRESS_XPOS, DOWNLOAD_PROGRESS_YPOS,
									DOWNLOAD_PROGRESS_XPOS+DOWNLOAD_PROGRESS_WIDTH,
									DOWNLOAD_PROGRESS_YPOS+DOWNLOAD_PROGRESS_HEIGHT);


}

void init_download_progress(uint32_t size) {

	filesize = size;

	tft_fill_rect (BYTE2COLOR (100,100,100), DOWNLOAD_PROGRESS_XPOS, DOWNLOAD_PROGRESS_YPOS,
									DOWNLOAD_PROGRESS_XPOS+DOWNLOAD_PROGRESS_WIDTH,
									DOWNLOAD_PROGRESS_YPOS+DOWNLOAD_PROGRESS_HEIGHT);

}


void create_system_info_screen (void) {

uint16_t addr; 

	tft_clrscr(TFT_COLOR_WHITE);

    printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "Nut/OS %s ", NutVersionString());
    printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "Firmware V%d.%d", pgm_read_byte_far((char*)&bootlodrinfo.app_version +1), pgm_read_byte_far((char*)&bootlodrinfo.app_version));

	addr = eib_get_device_address(EIB_DEVICE_CHANNEL);
//    printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "Phys. Addr %d.%d.%d", (addr >> 4) & 0x0f, addr & 0x0f, (addr >> 8) & 0xff );
    printf_tft( TFT_COLOR_RED, TFT_COLOR_WHITE, "Phys. Addr %d.%d.%d", (addr >> 4) & 0x0f, addr & 0x0f, (addr >> 8) & 0xff );
	if (display_orientation == DISPLAY_ORIENTATION_HOR)
//    	printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "Horizontal");
    	printf_tft( TFT_COLOR_BLACK, TFT_COLOR_WHITE, "Horizontal");
	else if (display_orientation == DISPLAY_ORIENTATION_90L)
//    	printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "90 left");
    	printf_tft( TFT_COLOR_BLACK, TFT_COLOR_WHITE, "90 left");
	else if (display_orientation == DISPLAY_ORIENTATION_90R)
//    	printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "90 right");
    	printf_tft( TFT_COLOR_BLACK, TFT_COLOR_WHITE, "90 right");
	else if (display_orientation == DISPLAY_ORIENTATION_UPSIDE)
//    	printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "180");
    	printf_tft( TFT_COLOR_BLACK, TFT_COLOR_WHITE, "180");

	if (eib_get_status() == EIB_NORMAL)
//    	printf_tft( TFT_COLOR_BLUE, TFT_COLOR_WHITE, "EIB online");
    	printf_tft( TFT_COLOR_BLACK, TFT_COLOR_WHITE, "EIB online");
	else 
    	printf_tft( TFT_COLOR_RED, TFT_COLOR_WHITE, "EIB offline");

//	printf_tft (TFT_COLOR_BLUE, TFT_COLOR_WHITE, "TFT Ctrl = %d, R00=%4.4x", controller_type, controller_id);
	printf_tft (TFT_COLOR_BLACK, TFT_COLOR_WHITE, "TFT Ctrl = %d, R00=%4.4x", controller_type, controller_id);
	
	draw_button (MONITOR_BUTTON_XPOS, MONITOR_BUTTON_YPOS, BUTTON_WIDTH, "Monitor");
	draw_button (DOWNLOAD_BUTTON_XPOS, DOWNLOAD_BUTTON_YPOS, BUTTON_WIDTH, "Download");
	draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
	system_page_active = SYSTEM_PAGE_MAIN;

}


char* get_download_files (uint8_t i) {

_LCD_FILE_NAMES_t *fname;

	if (i >= sd_files)
		return "error";

	fname = sd_file_names;
	fname += i;
	return fname->fname;

}

void resume_busmon_page (void) {

	// write header
	showzifustr(75,1, (unsigned char*)"Busmon       ", TFT_COLOR_BLACK, TFT_COLOR_WHITE);

	draw_button (PAUSE_BUTTON_XPOS, PAUSE_BUTTON_YPOS, BUTTON_WIDTH, "Pause");
	system_page_active = SYSTEM_PAGE_BUSMON;
}

void create_monitor_selection_page (void) {

	// clear page contents
	tft_clrscr(TFT_COLOR_WHITE);

	// write header
	showzifustr(75,100, (unsigned char*)"Monitor selection", TFT_COLOR_BLACK, TFT_COLOR_WHITE);

	draw_button (BUSMON_BUTTON_XPOS, BUSMON_BUTTON_YPOS, BUTTON_WIDTH, "Busmon");
	draw_button (HARDWARE_MONITOR_BUTTON_XPOS, HARDWARE_MONITOR_BUTTON_YPOS, BUTTON_WIDTH, "Hardware");
	draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
	// set active system page
	system_page_active = SYSTEM_PAGE_MONITOR_SELECTION;
}

void create_hardware_monitor_page (void) {

	// clear page contents
	tft_clrscr(TFT_COLOR_WHITE);
	// write header
	showzifustr(75,1, (unsigned char*)"Hardware Monitor", TFT_COLOR_BLACK, TFT_COLOR_WHITE);

	draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
	// set active system page
	monitor_y = 15;
	monitor_color = TFT_COLOR_WHITE;
	system_page_active = SYSTEM_PAGE_HARDWARE_MONITOR;
}

void create_busmon_page (void) {

	// clear page contents
	tft_clrscr(TFT_COLOR_WHITE);

	// write header

	draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
	// set active system page
	monitor_y = 15;
	monitor_color = TFT_COLOR_WHITE;
	resume_busmon_page ();
}

void create_busmon_paused_page (void) {
	// write header
	showzifustr(75,1, (unsigned char*)"Busmon paused", TFT_COLOR_WHITE, TFT_COLOR_RED);

	draw_button (RESUME_BUTTON_XPOS, RESUME_BUTTON_YPOS, BUTTON_WIDTH, "Resume");
	// set active system page
	system_page_active = SYSTEM_PAGE_BUSMON_PAUSED;
}



void create_download_selection_page (void) {

	// clear page contents
	tft_clrscr(TFT_COLOR_WHITE);

	// write header
	showzifustr(75,1, (unsigned char*)"Select file for download", TFT_COLOR_BLACK, TFT_COLOR_WHITE);

	sd_files = 0;
	// mount SD card
	showzifustr(30,80, (unsigned char*)"Please wait", TFT_COLOR_BLACK, TFT_COLOR_WHITE);
	showzifustr(30,94, (unsigned char*)"Mounting SD card...", TFT_COLOR_BLACK, TFT_COLOR_WHITE);
    if (!mount_SD_card ()) {
#ifdef LCD_DEBUG
        puts("failed\n");
#endif
		showzifustr(30,108, (unsigned char*)"Error, can't read from SD card!", TFT_COLOR_RED, TFT_COLOR_WHITE);
		draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
        return;
	}
	// get list of lcd files
	sd_files = get_list_of_lcd_files (&sd_file_names);
	if (!sd_files) {
		showzifustr(30,108, (unsigned char*)"No .lcdb file found!", TFT_COLOR_RED, TFT_COLOR_WHITE);
		draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
		return;
	}

	// setup selection list
	init_selection_list (&get_download_files, sd_files, 0, 10, 20, 300, 160);

	// create buttons
	draw_button (DOWNLOAD_LIST_UP_XPOS, DOWNLOAD_LIST_UP_YPOS, BUTTON_WIDTH_SMALL, "Up");
	draw_button (DOWNLOAD_LIST_DOWN_XPOS, DOWNLOAD_LIST_DOWN_YPOS, BUTTON_WIDTH_SMALL, "Down");
	draw_button (DOWNLOAD_BUTTON_XPOS, DOWNLOAD_BUTTON_YPOS, BUTTON_WIDTH, "Download");
	draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");

	// set active system page
	system_page_active = SYSTEM_PAGE_DOWNLOAD_SELECTION;
}

void create_download_progress_page (void) {

_LCD_FILE_NAMES_t *fname;
uint8_t s;

	// get selected file name
	s = selection_list_get_selected_item ();
	fname = sd_file_names+s;

	// clear page contents
	tft_clrscr(TFT_COLOR_WHITE);

	// write header
	showzifustr(80,1, (unsigned char*)"Download", TFT_COLOR_BLACK, TFT_COLOR_WHITE);
	showzifustr(10,30, (unsigned char*)"File name:", TFT_COLOR_BLACK, TFT_COLOR_WHITE);
	showzifustr(10,45, (unsigned char*) fname->fname, TFT_COLOR_BLACK, TFT_COLOR_WHITE);

	// get selected file name
	if (!download_file_from_sd_card (fname)) {
		showzifustr(10,60, (unsigned char*)"success!", TFT_COLOR_BLACK, TFT_COLOR_GREEN);
		tft_set_cursor (START_CHAR_X_POS, 80);
		init_system_from_flash ();
		init_physical_address_from_Flash ();
	}
	else {
		showzifustr(10,60, (unsigned char*)"fail!", TFT_COLOR_BLACK, TFT_COLOR_RED);
	}

	// release all allocated resources
	free (sd_file_names);
	unmont_SD_card();

	// show exit button
	draw_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, "Exit");
	// set active system page
	system_page_active = SYSTEM_PAGE_DOWNLOAD_PROGRESS;
}

void process_system_page_event (t_touch_event *evt) {

	if (evt->state == TOUCHED) {

		if (system_page_active == SYSTEM_PAGE_MAIN) {
			// System info main page
			// check, if busmon button is hit
			if (check_button (MONITOR_BUTTON_XPOS, MONITOR_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_monitor_selection_page ();
			}	
			// check, if download button is hit
			if (check_button (DOWNLOAD_BUTTON_XPOS, DOWNLOAD_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_download_selection_page ();
			}	
			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				system_page_active = SYSTEM_PAGE_NONE;
				set_page (0);
			}
		}
		else if (system_page_active == SYSTEM_PAGE_DOWNLOAD_SELECTION) {
			// System download page

			if (sd_files > 0) {

				// check, if UP button is hit
				if (check_button (DOWNLOAD_LIST_UP_XPOS, DOWNLOAD_LIST_UP_YPOS, BUTTON_WIDTH_SMALL, evt)) {
					sound_beep_on (0);
					selection_list_update_selection	(-1);
				}
				// check, if UP button is hit
				if (check_button (DOWNLOAD_LIST_DOWN_XPOS, DOWNLOAD_LIST_DOWN_YPOS, BUTTON_WIDTH_SMALL, evt)) {
					sound_beep_on (0);
					selection_list_update_selection	(+1);
				}

				// check, if download button is hit
				if (check_button (DOWNLOAD_BUTTON_XPOS, DOWNLOAD_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
					sound_beep_on (0);
					create_download_progress_page ();
				}	
			}
			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				free (sd_file_names);
				unmont_SD_card();
				create_system_info_screen ();
			}
		}
		else if (system_page_active == SYSTEM_PAGE_DOWNLOAD_PROGRESS) {

			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_system_info_screen ();
			}
		}
		else if (system_page_active == SYSTEM_PAGE_BUSMON) {

			// check, if Pause button is hit
			if (check_button (PAUSE_BUTTON_XPOS, PAUSE_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_busmon_paused_page ();
			}
			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_system_info_screen ();
			}
		}
		else if (system_page_active == SYSTEM_PAGE_BUSMON_PAUSED) {

			// check, if Resume button is hit
			if (check_button (RESUME_BUTTON_XPOS, RESUME_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				resume_busmon_page ();
			}
			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_system_info_screen ();
			}
		}
		else if (system_page_active == SYSTEM_PAGE_MONITOR_SELECTION) {

			if (check_button (BUSMON_BUTTON_XPOS, BUSMON_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_busmon_page ();
			}
			if (check_button (HARDWARE_MONITOR_BUTTON_XPOS, HARDWARE_MONITOR_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_hardware_monitor_page ();
			}
			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_system_info_screen ();
			}
		}
		else if (system_page_active == SYSTEM_PAGE_HARDWARE_MONITOR) {

			// check, if Exit button is hit
			if (check_button (EXIT_BUTTON_XPOS, EXIT_BUTTON_YPOS, BUTTON_WIDTH, evt)) {
				sound_beep_on (0);
				create_system_info_screen ();
			}
		}
	}
}

void check_screen_lock() {

	if (screen_lock) {
		screen_lock--;
		if (screen_lock) {
			//update progress bar
			show_download_progress (SCREEN_LOCK_TIME - screen_lock);
		}
		else {
			//jump to previous page
			sound_beep_on (0);
			system_page_active = SYSTEM_PAGE_NONE;
			recover_active_page ();
		}
	}


}

void create_screen_lock () {

	screen_lock = SCREEN_LOCK_TIME;
	tft_clrscr (TFT_COLOR_WHITE);
	showzifustr(80,1, (unsigned char*)"Screen is locked", TFT_COLOR_RED, TFT_COLOR_WHITE);
	init_download_progress (SCREEN_LOCK_TIME);

}

void process_touch_event (t_touch_event* evt) {

	//ignore touch events while screen is locked
	if (screen_lock)
		return;

	// Did the user touch the system control area of the display
	if (evt->lx < 0) {
		if (evt->state == TOUCHED) {
			if ((evt->ly < 80) && (!system_page_active)) {
				sound_beep_on (0);
				set_page (0);
			}
			else if ((evt->ly < 160) && (!system_page_active)){
				sound_beep_on (0);
				create_system_info_screen ();
			}
			else if ((evt->ly > 160) && (!system_page_active)) {
				//touch lock for wiping
				sound_beep_on (0);
				create_screen_lock ();
			} 
		}
	}
	else {

		if (system_page_active)
			process_system_page_event (evt);
		else 
			page_touch_event (evt);
	}
}

void init_screen_control () {

	screen_lock = 0;
	system_page_active = SYSTEM_PAGE_NONE;

}

void busmon_show (t_eib_frame* msg) {

int i;
unsigned int xp = 1;
#define BUFF_SIZE	5
char buffer[BUFF_SIZE];
int d;

	if (system_page_active != SYSTEM_PAGE_BUSMON)
		return;

	for (i=0; i < msg->len; i++) {
		d = msg->frame[i] & 0xff;
		vsprintf_P (buffer, PSTR("%.2X "), (int*)&d);
		xp = showzifustr(xp,monitor_y,(unsigned char*) buffer,TFT_COLOR_BLACK,monitor_color);
		if ((i == 1) || (i == 3))
			xp -= 4;
	}
	// clear until e/o line
	tft_fill_rect (monitor_color, xp,monitor_y,get_max_x(),monitor_y+10);

	monitor_y += 10;
	if (monitor_y > 190) {
		monitor_y = 15;
		if (monitor_color == TFT_COLOR_WHITE)
			monitor_color = TFT_COLOR_LIGHTGRAY;
		else monitor_color = TFT_COLOR_WHITE;
	}
}

void hwmon_goto_next_line (void) {

	monitor_y += 10;
	if (monitor_y > 190) {
		monitor_y = 15;
		if (monitor_color == TFT_COLOR_WHITE)
			monitor_color = TFT_COLOR_LIGHTGRAY;
		else monitor_color = TFT_COLOR_WHITE;
	}

}

void hwmon_show_ir_event () {

	if (system_page_active != SYSTEM_PAGE_HARDWARE_MONITOR)
		return;

	// clear until e/o line
//	tft_fill_rect (monitor_color, 0,monitor_y,TFT_MAX_X,monitor_y+10);
//FIXME: find better way to clear this line
	tft_set_cursor (1, monitor_y);
	printf_tft (TFT_COLOR_BLACK,monitor_color,"RC5: A=%2.2d C=%2.2d           ", rc5_a, rc5_c);
	hwmon_goto_next_line ();
}


void hwmon_show_ds1820_event (double t, uint8_t c, uint8_t crc, uint8_t ok) {

	if (system_page_active != SYSTEM_PAGE_HARDWARE_MONITOR)
		return;

	// clear until e/o line
//	tft_fill_rect (monitor_color, 0,monitor_y,TFT_MAX_X,monitor_y+10);
//FIXME: find better way to clear this line
	tft_set_cursor (1, monitor_y);

	if (!ok) {
		printf_tft (TFT_COLOR_BLACK,TFT_COLOR_RED,"DS1820 (%s): no slave   ", channel_names[c] );
	}
	else if (!crc) {
		printf_tft (TFT_COLOR_BLACK,monitor_color,"DS1820 (%s): %2.2f     ", channel_names[c], t);
	}
	else {
		printf_tft (TFT_COLOR_BLACK,TFT_COLOR_RED,"DS1820 (%s): bad CRC   ", channel_names[c] );
	}

	hwmon_goto_next_line ();
}


void hwmon_show_button_event (uint8_t btn, uint8_t state) {

	if (system_page_active != SYSTEM_PAGE_HARDWARE_MONITOR)
		return;

	// clear until e/o line
//	tft_fill_rect (monitor_color, 0,monitor_y,TFT_MAX_X,monitor_y+10);
//FIXME: find better way to clear this line
	tft_set_cursor (1, monitor_y);
	printf_tft (TFT_COLOR_BLACK,monitor_color,"Btn: %d -> %d           ", btn, state);

	hwmon_goto_next_line ();
}

uint8_t is_system_page_active () {
	return (system_page_active != SYSTEM_PAGE_NONE) || is_screen_locked ();
}

uint8_t is_screen_locked () {
	return (screen_lock > 0);
}
